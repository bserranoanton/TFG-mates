Se incluyen también simulaciones con distintas poblaciones de células T pero que presentan la misma 
afinidad con el patógeno. 